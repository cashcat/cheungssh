17MonIP Changelog
=================

Version 0.2.6
-------------

Released on April 21, 2015.

- support python wheel


Version 0.2.5
-------------

Released on April 21, 2015.

- update dat version to 20150401
- use binary search to replace line search for speed boost, via #7

.. _`#7`: https://github.com/lxyu/17monip/issues/7


Version 0.2.4
-------------

Released on November 18, 2014.

- update dat version to 20141001
- code rewrite via `#3`_ and `#5`_,

.. _`#3`: https://github.com/lxyu/17monip/issues/3
.. _`#5`: https://github.com/lxyu/17monip/issues/5


Version 0.2.3
-------------

Released on August 6, 2014.

- add support for py2.6, py3.2


Version 0.2.2
-------------

Released on August 5, 2014.

- update dat version to 20140804
- update tests and docs


Version 0.2.1
-------------

Released on July 4, 2014.

- update dat version to 20140701
- change bin script from 'ip' to 'iploc' via `#2`_.

.. _`#2`: https://github.com/lxyu/17monip/issues/2


Version 0.2.0
-------------

Released on June 4, 2014.

- update dat version to 20140601
- increased accuracy from province to city
- add command line utils
- add tests


Version 0.1.0
-------------

First release.
