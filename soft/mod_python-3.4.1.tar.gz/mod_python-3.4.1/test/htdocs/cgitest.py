

print "Content-type: text/plain\n"
print "test ok"

