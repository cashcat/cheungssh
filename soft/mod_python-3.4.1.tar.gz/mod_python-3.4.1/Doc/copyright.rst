*********
Copyright
*********

Mod_python and this documentation is:

Copyright © 2000, 2001, 2013 Gregory Trubetskoy

Copyright © 2002, 2003, 2004, 2005, 2006, 2007 Apache Software Foundation

-------

See :ref:`history-and-license` for complete license and permissions information.
