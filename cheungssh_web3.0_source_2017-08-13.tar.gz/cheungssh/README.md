# 全程独立研发，虽然不优秀，但衷心希望能给予支持和理解。
#### 因为项目太大，浏览器下载很可能导致不完整。所以强烈建议您用（git命令下载）：
####     git clone https://git.oschina.net/CheungSSH_OSC/CheungSSH.git 
####作者  ：张其川
####Q群  ：585393390
