# Tests that raise ImportError should not fail silently.
# This is a support fixture for one test case in test_runner

raise ImportError
